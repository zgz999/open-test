---
name: Hardware Support
about: Suggest adding hardware support
title: ''
labels: hardware support
assignees: ''

---

**Is this request related to a missing driver support for a particular hardware platform, SoC or board? Please describe.**
<!-- Describe in details the hardware support being requested and why this support benefits Zephyr. -->

**Describe why you are asking for this support?**
<!-- Describe why you are asking for this support. -->

**Additional context**
<!-- Add any other context or graphics (drag-and-drop an image) about the hardware here. -->
